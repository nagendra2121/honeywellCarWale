﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CarWale.Startup))]
namespace CarWale
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
