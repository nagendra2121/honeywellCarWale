﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CarWaleApi.Models;
namespace CarWaleApi.Controllers
{
    public class CarAPIController : ApiController
    {

        IList<Car> Cars = new List<Car>()
        {
            new Car()
            {
                Brand = "Maruthi Siziki",
                Model="Alto 800",
                BodyType="Saden",
                FuelType="Petrol"
            },
              new Car()
            {
                Brand = "BMW",
                Model="330i",
                BodyType="Sedan",
                FuelType="Diesel"
            },
                new Car()
            {
                Brand = "BMW 5Serice",
               Model="520d",
                BodyType="Couple",
                FuelType="LPG"
            },
                  new Car()
            {
                Brand = "Hyundai",
                Model="28987c",
                BodyType="Hachback",
                FuelType="Electric"
            },
                         new Car()
            {
                Brand = "Hyundai Elite",
                Model="5007c",
                BodyType="Van",
                FuelType="CNG"
            }
               
                  
        };
        [HttpGet]
        public  IList<Car> GetCars()
        {
            return Cars;
        }
    }
}
